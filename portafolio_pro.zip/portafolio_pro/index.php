<?php
header('Location:portafolio.html');
?>